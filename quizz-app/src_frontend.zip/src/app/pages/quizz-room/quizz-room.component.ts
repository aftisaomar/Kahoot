import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quizz-room',
  templateUrl: './quizz-room.component.html',
  styleUrls: ['./quizz-room.component.scss']
})
export class QuizzRoomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
