import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { QuizzRoomRoutingModule } from './quizz-room-routing.module';
import { QuizzRoomComponent } from './quizz-room.component';


@NgModule({
  declarations: [QuizzRoomComponent],
  imports: [
    CommonModule,
    QuizzRoomRoutingModule
  ]
})
export class QuizzRoomModule { }
