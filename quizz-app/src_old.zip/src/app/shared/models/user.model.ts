export class User {
    public id = '';
    public email = '';
}