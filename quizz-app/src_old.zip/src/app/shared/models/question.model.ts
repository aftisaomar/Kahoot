export class Question {
    _id: string;
    contenu: string;
    reponse: string;
    proposition1: string;
    proposition2: string;
    proposition3: string;
    proposition4: string;
    createdAt: string;
    updatedAt: string;
}