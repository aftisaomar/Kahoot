import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {CountdownModule} from 'ngx-countdown'
import {MatCardModule} from '@angular/material/card'
import { QuizzRoomRoutingModule } from './quizz-room-routing.module';
import { QuizzRoomComponent } from './quizz-room.component';


@NgModule({
  declarations: [QuizzRoomComponent],
  imports: [
    CommonModule,
    QuizzRoomRoutingModule,
    MatCardModule,
    CountdownModule
  ]
})
export class QuizzRoomModule { }
