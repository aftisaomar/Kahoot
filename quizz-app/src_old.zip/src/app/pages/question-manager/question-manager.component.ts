import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/shared/models/question.model';
import { QuizzDataService } from 'src/app/core/services/data/quizz-data.service';
import { MatDialog } from '@angular/material/dialog';
import { QuestionEditComponent } from './question-edit/question-edit.component';

@Component({
  selector: 'app-question-manager',
  templateUrl: './question-manager.component.html',
  styleUrls: ['./question-manager.component.scss']
})
export class QuestionManagerComponent implements OnInit {

  questions: Question[] = [];

  constructor(private _quizzData: QuizzDataService,
    public dialog: MatDialog) { }

  ngOnInit(): void {
    this._quizzData.findAll().subscribe(
      (quizzes) => {
        quizzes.map(quizz => {
          quizz.questions.forEach(q => this.questions.push(q));
        })

      },
      (error) => {
        console.log("Error : ", error);
      }
    )
  }

  onShowEditQuestion(i: number) {
    const dialogRef = this.dialog.open(QuestionEditComponent, {
      width: '50%',
      data: {
        question: this.questions[i],
        editMode: true
      },
      autoFocus: false
    });

    dialogRef.afterClosed().subscribe(quizzData => {
      /*if (quizzData) {
        this._quizzData.add(quizzData).subscribe(
          (newQuizz) => {
            this.questions.push(newQuizz);
          },
          (error) => {
            console.log("Error : ", error);
          }
        );
      }*/
    });
  }

  onDeleteQuestion(i: number) {

  }

}
