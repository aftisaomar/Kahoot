const express = require('express');
require('./db/mongoose')
const cors = require('cors');
const userRouter = require('./routers/user');
const quizzRouter = require('./routers/quizz');
const questionRouter = require('./routers/question')

const app = express();
app.use(cors({
    origin: '*'
}))
const port = process.env.PORT || 3000;

//Configure automatic json parsing
app.use(express.json());
// Registering routers
app.use(userRouter);
app.use(quizzRouter)
app.use(questionRouter)

app.listen(port, () => {
    console.log(`Server is up and running on port ${port}`);
})