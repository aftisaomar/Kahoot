
const tabSocket = []

const gameQuizz = io.of("playQuizz");
gameQuizz.on('connection',(socket)=>{

    tabSocket.push(socket);
    
  
})

const playQuizz = io.of("startQuizz")

playQuizz.on('connection',(socket)=>{

  socket.emit('message',"connexion de l'admin");
  let counter = 0;

  let i = setInterval(function(){
    //Envoyer tout d'abord nos information quizz
    tabSocket.forEach(socketUser => socketUser.emit('quizz',quizz));
    
    tabSocket.forEach(socketUser => socketUser.emit('question',questions[counter]));

    //socket.to('partie').emit('question',questions[counter])
    console.log("envoi au client de la question : "+ counter)

    counter++;
    if(counter > 3) {
      tabSocket.forEach(socketUser => socketUser.emit('end'));
      clearInterval(i);
    }
  }, 10000)
})  